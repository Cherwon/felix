Using VBA scripting to analyse generated stock market data.
Usin a set of files "C:\Users\felix\Downloads\Starter_Code (2).zip"
Create set of script to run;
The ticker symbol

Yearly change from the opening price at the beginning of a given year to the closing price at the end of that year.

The percentage change from the opening price at the beginning of a given year to the closing price at the end of that year.

The total stock volume of the stock.
Using the, conditional formatting it will highlight positive change in green and negative change in red.
